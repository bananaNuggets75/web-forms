﻿using Polgo_Constructions_Projects.Models;

namespace Polgo_Constructions_Projects.Services
{
    public interface IProjectsService
    {
        Task<List<Projects>> GetAllProjectsAsync();
        Task<Projects> GetProjectsByIdAsync(int id);
        Task AddProjectsAsync(Projects project);
        Task UpdateProjectsAsync(Projects project, int id);
        Task DeleteProjectsAsync(int id);

    }
}
