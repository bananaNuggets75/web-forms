﻿using Polgo_Constructions_Projects.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace Polgo_Constructions_Projects.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) :
base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Materials>().HasData(

                new Materials { Id = 1, materialName = "hammer", description = "hamer abc", length = "15 x 50 x 55 in.", price = "500" }

                );

            modelBuilder.Entity<Projects>().HasData(

                new Projects { Id = 1, projectName = "railing abc", constructionType = "railing", description = "railing for the people", location = "Japan", totalBudget = "500000" }

                );
        }

        public DbSet<Materials> Materials { get; set; }
        public DbSet<Projects> Projects { get; set; }
    }
}
