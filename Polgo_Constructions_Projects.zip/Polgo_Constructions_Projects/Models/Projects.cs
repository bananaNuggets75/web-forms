﻿namespace Polgo_Constructions_Projects.Models
{
    public class Projects
    {
        public int Id { get; set; }
        public string? projectName { get; set; }
        public string? constructionType { get; set; }
        public string? description { get; set; }
        public string? location { get; set; }
        public string? totalBudget { get; set; }
    }
}
