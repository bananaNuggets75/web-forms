﻿namespace Polgo_Constructions_Projects.Models
{
    public class Materials
    {
        public int Id { get; set; }
        public string? materialName { get; set; }
        public string? description { get; set; }
        public string? length { get; set; }
        public string? price { get; set; }
    }
}
