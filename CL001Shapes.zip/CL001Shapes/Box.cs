﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CL001Shapes
{
    public class Box : Rectangle
    {
        public double height { get; set; }

        private double volume;

        public Box() : base()
        {
            height = 0;
        }

        public Box(double length, double width, double height) 
            :base(length, width)
        {
            this.height = height;
        }

        public Box(Box box) :base(box.length, box.width)
        {
            this.height = box.height;
        }

        private void calcVolume() 
        {
            volume = getArea() * height;
        }

        public double getVolume() 
        {
            calcVolume();
            return volume;
        }

        public override string ToString()
        {
            calcVolume();
            return base.ToString() + " and Volume: " + volume;
        }
    }
}
