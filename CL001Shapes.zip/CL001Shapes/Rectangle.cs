﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CL001Shapes
{
    public class Rectangle
    {
        public double length { get; set; }
        public double width { get; set; }

        private double area;
        private double perimeter;

        public Rectangle() // default constructor
        {
            length = 0;
            width = 0;
        }

        public Rectangle(double length, double width) // constructor with parameters
        {
            this.length = length;
            this.width = width;
            
        }

        public Rectangle(Rectangle rectangle) // copy constructor
        {
            this.length = rectangle.length;
            this.width = rectangle.width;
        }

        private void calcArea() 
        {
            area = length * width;
        }

        public double getArea() 
        {
            calcArea();
            return area;
        }

        private void calcPerimeter() 
        {
            perimeter = (length * 2) + (width * 2);
        }

        public double getPerimeter() 
        {
            calcPerimeter();
            return perimeter;
        }

        public override string ToString() 
        {
            calcArea();
            calcPerimeter();
            return "Area: " + area + " and Perimeter: " + perimeter;
        }
    }
}
