using Polgo_Constructions_Projects.Data;
using Polgo_Constructions_Projects.Models;
using Microsoft.EntityFrameworkCore;

namespace Polgo_Constructions_Projects.Services
{
    public class ProjectService: IProjectsService
    {
        private readonly DataContext _context;
        public ProjectService(DataContext context)
        {
            _context = context;
        }

        public async Task AddProjectsAsync(Projects project)
        {
            _context.Projects.Add(project);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteProjectsAsync(int id)
        {
            var project = await _context.Projects.FindAsync(id);
            if (project != null)
            {
                _context.Projects.Remove(project);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<Projects>> GetAllProjectsAsync()
        {
            var result = await _context.Projects.ToListAsync();
            return result;
        }

        public async Task<Projects> GetProjectsByIdAsync(int id)
        {
            var project = await _context.Projects.FindAsync(id);
            return project;
        }

        public async Task UpdateProjectsAsync(Projects project, int id)
        {
            var dbProject = await _context.Projects.FindAsync(id);
            if (project != null)
            {
                dbProject.Name = project.Name;
                dbProject.Type = project.Type;
                dbProject.Description = project.Description;
                dbProject.Location = project.Location;
                dbProject.Budget = project.Budget;
                await _context.SaveChangesAsync();
            }
        }
    }
}
