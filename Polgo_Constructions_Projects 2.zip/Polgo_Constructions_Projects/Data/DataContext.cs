﻿using Polgo_Constructions_Projects.Models;
using Microsoft.EntityFrameworkCore;

namespace Polgo_Constructions_Projects.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) :
base(options)
        {
        }
         protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Materials>().HasData(
                
                new Materials { Id = 1, Name = "hammer", Description = "hamer abc", Dimension = "15 x 50 x 55 in.", Price = "500" }
                
                );

            modelBuilder.Entity<Projects>().HasData(

                new Projects { Id = 1, Name = "railing abc", Type = "railing", Description = "railing for the people", Location = "Japan, Budget = "500000" }

                );
        }

        public DbSet<Materials> Materials { get; set; }
        public DbSet<Projects> Projects { get; set; }
    }
}
